set -x
MYDIR=${TSDBDIR-'/usr/local/opentsdb'}
tsdtmp=${TMPDIR-'/tmp'}/tsd # For best performance, make sure 
mkdir -p "$tsdtmp"          # your temporary directory uses tmpfs 
tsdb tsd --port=4242 --staticroot=${MYDIR}/staticroot --cachedir="$tsdtmp"
