package samples;

import com.vmware.ee.statsfeeder.*;
import com.vmware.ee.statsfeeder.PerfMetricSet.PerfMetric;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * This Receiver is written to illustrate how to write a new receiver for StatsFeeder
 *
 * It this is a very simple receiver that just receives the metrics and outputs them
 * to the console with some formatting.
 */
public class SampleStatsReceiver implements StatsListReceiver,
		StatsFeederListener, StatsExecutionContextAware {
	Log logger = LogFactory.getLog(SampleStatsReceiver.class);

	private String name = "SampleStatsReceiver";
	private ExecutionContext context;
	private PrintStream writer;

	/**
	 * This constructor will be called by StatsFeeder to load this receiver. The props object passed
	 * is built from the content in the XML configuration for the receiver.
	 * <pre>
	 *    {@code
	 *    <receiver>
     *      <name>sample</name>
     *      <class>com.vmware.ee.statsfeeder.SampleStatsReceiver</class>
     *      <!-- If you need some properties specify them like this
     *      <properties>
     *          <property>
     *              <name>some_property</name>
     *              <value>some_value</value>
     *          </property>
     *      </properties>
     *      -->
     *    </receiver>
     *    }
	 * </pre>
	 * @param name
	 * @param props
	 */
	public SampleStatsReceiver(String name, Properties props) {
		this.name = name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}


	/**
	 * This method is called when the receiver is initialized and passes the
	 * StatsFeeder execution context which can be used to look up properties
	 * or other configuration data.
     *
     * It can also be used to retrieve the vCenter connection information
	 *
	 * @param context - The current execution context
	 */
	@Override
	public void setExecutionContext(ExecutionContext context) {
		this.context = context;
	}

	/**
	 * Main receiver entry point. This will be called for each entity and each metric which were
	 * retrieved by StatsFeeder.
	 *
	 * @param entityName - The name of the statsfeeder entity being retrieved
	 * @param metricSet - The set of metrics retrieved for the entity
	 */
	@Override
	public void receiveStats(String entityName, PerfMetricSet metricSet) {
		if (metricSet != null) {
			//-- Samples come with the following date format
			final SimpleDateFormat SDF = new SimpleDateFormat(
					"yyyy-MM-dd'T'HH:mm:ss'Z'");
			SDF.setTimeZone(TimeZone.getTimeZone("UTC"));
            System.out.println(entityName);
			try {
				Iterator<PerfMetric> metrics = metricSet.getMetrics();
				while (metrics.hasNext()) {
					PerfMetric sample = metrics.next();
                    System.out.println(String.format("\t%s - %s", sample.getTimestamp(), sample.getValue()));
				}
			} catch (Throwable t) {
				logger.error("Error processing entity stats ", t);
			}

		}
	}

	/**
	 * This method is guaranteed to be called at the start of each retrieval in single or feeder mode.
	 * Receivers can place initialization code here that should be executed before retrieval is
	 * started.
	 */
	@Override
	public void onStartRetrieval() {
		System.out.println("Started retrieval...");
	}

	/**
	 * This method is guaranteed to be called, just once, at the end of each retrieval in single or feeder mode.
	 * Receivers can place termination code here that should be executed after the retrieval is
	 * completed.
	 */
	@Override
	public void onEndRetrieval() {
        System.out.println("Ended retrieval...");
	}

}